//Windsweep Bane Mercy Miracle DireThunder RightfulRuler WindAdept FlickeringFlower SureStrike Lethality
//Ignis GoldenLotus Sol Luna SandStorm BackAtYou GraspingVoid, SoulBlade
personalSkills: {

}
