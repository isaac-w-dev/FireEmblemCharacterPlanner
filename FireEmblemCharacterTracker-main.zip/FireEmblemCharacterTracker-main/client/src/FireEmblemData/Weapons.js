//FellStone FellRuinstone FellMagicstone FellWeightstone FellSpark FellSparkFX5, FellArcana
//RuneSword AegisShield Thyrsus RafailGem FireBreath FogBreath IceBreath FlameBreath DarkBreath CamillasAxe Areadbhar SwordofCreator, Vajra-Mushti
//Effectiveness
//ForcedFollowUp Smash NoFollow
//Range
//Magic Physical