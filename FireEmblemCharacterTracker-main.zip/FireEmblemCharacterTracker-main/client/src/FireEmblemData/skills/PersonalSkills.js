expertise: {
    characterName: "Jean";
    //modifier:  Multiply class growths by 2
}